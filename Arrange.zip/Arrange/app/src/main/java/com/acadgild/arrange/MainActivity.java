package com.acadgild.arrange;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import java.util.Arrays;
import java.util.Collections;


public class MainActivity extends Activity implements View.OnClickListener{


    ListView list;
    //Defining a string array
    String[] months=new String[]{
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//Loading the main layout
        //Defining Buttons and setting onClickListner
        Button btn=(Button)findViewById(R.id.button);
        btn.setOnClickListener(this);
        Button btn2=(Button)findViewById(R.id.button2);
        btn2.setOnClickListener(this);
        list=(ListView)findViewById(R.id.listView);//Defining listview
        adapterView();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button:
                Arrays.sort(months);//Sorting the array
                adapterView();//setting the adapter to refresh the list
                break;
            case R.id.button2:
                Arrays.sort(months, Collections.reverseOrder());//Reverse sorting
                adapterView();//setting the adapter to refresh the list
                break;

        }
    }

//using this method to set adapter
    protected void adapterView(){
        //Binding the adapter with list and array string
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this, R.layout.listview_white_text,months);
        list.setAdapter(adapter);

    }
}
