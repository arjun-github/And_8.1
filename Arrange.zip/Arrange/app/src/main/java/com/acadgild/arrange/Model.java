package com.acadgild.arrange;

/**
 * Created by Arjun on 6/20/2017.
 */

class Model {
}
